import React from 'react'
import "./footer.scss"
function Footer() {
  return (
    <div className='footer-main'>
<p className='footer-p'>Panel v1.01</p>
<p className='footer-p'>Copyright © 2023 ODS Company</p>
    </div>
  )
}

export default Footer