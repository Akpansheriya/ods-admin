export const links = [
  {
    title: "Resumen",
    path: "/dashboard/resumen",
    icon: "bi bi-grid",
 
  },
  {
    title: "Citas agendadas",
    path: "/dashboard/citas",
    icon: "bi bi-card-list",
  },
  {
    title: "Calendario de Citas",
    path: "/dashboard/calendario",
    icon: "bi bi-calendar-event",
  },
  {
    title: "Mascotas",
    path: "/dashboard/mascotas",
    icon: "bi bi-gift",
  },
  {
    title: "Propietarios",
    path: "/dashboard/propietarios",
    icon: "bi bi-people-fill",
  },
  
  {
    title: "Inventario Productos",
    path: "/dashboard/Inventario",
    icon: "bi bi-bag-plus",
  },
]

