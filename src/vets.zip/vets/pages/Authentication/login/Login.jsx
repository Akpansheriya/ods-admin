import React from "react";
import { Button, Form, Row , Col } from "react-bootstrap";
import "../scss/main.scss";
import { useNavigate } from "react-router-dom";
function Login() {
  const navigate = useNavigate();

  return (
    <div className='section'>
    <Row className='row-class d-flex flex-center w-lg-50 pt-15 pt-lg-0 px-10'  >
    

<Col sm={12} md={6} lg={6}>
 <div className='left-container'>
<div className='left-inner-container'>
 <p className='main-heading'>Veterinaria <sup>ODS</sup></p>
 <p className='sub-heading'>Inicia sesión para entrar a tu cuenta</p>
</div>
 </div>
</Col>
<Col sm={12} md={6} lg={6}>
 <div className='right-container'>
     <div className='right-inner-container'>
         <div className='form-title'>
<p> Bienvenido,  <br/>Inicia sesión</p>
         </div>
 <Form>
   <Form.Group className="mb-3" controlId="formBasicEmail">
     <Form.Label>Correo electrónico</Form.Label>
     <Form.Control type="email" placeholder="Correo electrónico" />
     
   </Form.Group>

   <Form.Group className="mb-3" controlId="formBasicPassword">
     <Form.Label>Contraseña</Form.Label>
     <Form.Control type="password" placeholder="Contraseña" />
   </Form.Group>
  
   <Button onClick={() => {navigate("/dashboard/resumen")}} variant="primary" type="submit">
   Iniciar Sesión
   </Button>

  
 </Form>
 <hr></hr>
 <div className='forget-container'>
<p className='forget-title'>¿Olvidaste tu contraseña?</p>
<Button onClick={() => {navigate("/forget")}} className='forget-btn'  >
Recuperar contraseña
   </Button>
 </div>
 </div>
 </div>
</Col>

    </Row>

  
 </div>
  );
}

export default Login;
