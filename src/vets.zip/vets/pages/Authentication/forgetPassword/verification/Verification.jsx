import React, { useState } from "react";
import { Button, Col, Row } from "react-bootstrap";
import "../../scss/main.scss";
import { useNavigate } from "react-router-dom";
import Alert from "../../../../components/alert/Alert";

function Verification() {
  const navigate = useNavigate();
  const [modalShow, setModalShow] = useState(false);
 
  const handleHide = () => {
    setModalShow(false);
    navigate("/updatePassword");
  };
  return (
    <div>
      <div className="section">
        <Row className="row-class">
          <div className="container">
            <Col sm={12} md={6} lg={6}>
              <div className="left-container">
                <div className="left-inner-container">
                  <p className="main-heading">
                    Veterinaria <sup>ODS</sup>
                  </p>
                  <p className="sub-heading">
                    insea session para entrar a tu cuenta
                  </p>
                </div>
              </div>
            </Col>
            <Col sm={12} md={6} lg={6}>
              <div className="right-container">
                <div className="right-inner-container">
                  <div className="form-title">
                    <p>
                      {" "}
                      Enviamos un enlace a <br />
                      tu correo
                    </p>
                  </div>
                  <p className="forget-sub-title">
                    Te hemos enviado un enlace para restablecer la contraseña a
                    tu correo electrónico.
                  </p>
                  <p className="forget-sub-title">
                    No olvides de revisar tu carpeta de Correos no deseados o
                    Spam.
                  </p>

                  <Button
                    onClick={() => navigate("/")}
                    className="back-login-btn"
                    variant="primary"
                    type="submit"
                  >
                    Volver a Iniciar Sesión
                  </Button>

                  <Button onClick={() => setModalShow(true)}
                  
                    className='verification-link-btn' variant="primary"
                    type="submit"> Renviar
                  </Button>

                  <p className="time-counter">
                    Podrás reenviarlo en 60 segundos.
                  </p>
                  <Alert
                    show={modalShow}
                    onHide={handleHide}
                    msg={"Hemos reenviado el enlace a tu correo"}
                  />
                </div>
              </div>
            </Col>
          </div>
        </Row>
      </div>
    </div>
  );
}

export default Verification;
