import React from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap'
import "../../scss/main.scss"
import { useNavigate } from 'react-router-dom'
function ForgetPassword() {
    const navigate = useNavigate()
  return (
    <div>
    <div className='section'>
      <Row className='row-class'  >
       <div className='container'>

<Col sm={12} md={6} lg={6}>
   <div className='left-container'>
<div className='left-inner-container'>
   <p className='main-heading'>Veterinaria <sup>ODS</sup></p>
   <p className='sub-heading'>insea session para entrar a tu cuenta</p>
</div>
   </div>
</Col>
<Col sm={12} md={6} lg={6}>
   <div className='right-container'>
       <div className='right-inner-container'>
           <div className='form-title'>
<p>Recupera tu  <br/>contraseña</p>
           </div>
           <p className='forget-sub-title'>Ingresa tu correo para enviar tu contraseña.</p>
   <Form>
     <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Correo electrónico</Form.Label>
       <Form.Control type="email" placeholder="Correo electrónico" />
       
     </Form.Group>

    
    
     <Button onClick={() => {navigate("/verification")}} className='send-email-btn' variant="primary" type="submit">
     Enviar
     </Button>

    
   </Form>
  
   </div>
   </div>
</Col>
</div>
      </Row>

    
   </div>
   </div>
  )
}

export default ForgetPassword