import React, { useState } from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap'
import Alert from '../../../../components/alert/Alert';
import { useNavigate } from 'react-router-dom';

function UpdatePassword() {

  const [modalShow, setModalShow] = useState(false);
  const navigate = useNavigate();

  const handleModal = (e) => {
    e.preventDefault();
    setModalShow(true);
  };
  const handleHide = () => {
    setModalShow(false);
    navigate("/");
  };
  return (
    <div className='section'>
    <Row className='row-class'  >
     <div className='container'>

<Col sm={12} md={6} lg={6}>
 <div className='left-container'>
<div className='left-inner-container'>
 <p className='main-heading'>Veterinaria <sup>ODS</sup></p>
 <p className='sub-heading'>Inicia sesión para entrar a tu cuenta</p>
</div>
 </div>
</Col>
<Col sm={12} md={6} lg={6}>
 <div className='right-container'>
     <div className='right-inner-container'>
         <div className='form-title'>
<p>Actualizar tu  <br/>contraseña</p>
         </div>
         <p className='form-subtitle'>Ingresa tu nueva contraseña</p>
 <Form onSubmit={handleModal}>
   <Form.Group className="mb-3" controlId="formBasicEmail">
     <Form.Label>Crear contraseña</Form.Label>
     <Form.Control type="email" placeholder="Crear contraseña" />
     
   </Form.Group>

   <Form.Group className="mb-3" controlId="formBasicPassword">
     <Form.Label>Confirmar contraseña</Form.Label>
     <Form.Control type="password" placeholder="Confirmar contraseña" />
   </Form.Group>
  
   <Button variant="primary" type="submit">
   Actualizar
   </Button>

  
 </Form>
 <Alert
        show={modalShow}
        onHide={handleHide}
        msg={"Ha restablecido correctamente su contraseña."}
      />
 </div>
 </div>
</Col>
</div>
    </Row>

  
 </div>
  )
}

export default UpdatePassword