export const citasData = [
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "grey-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "grey-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
          {
            star: "grey-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star blank",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star blank",
          },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star blank",
          },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
        {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
          {
            star: "blue-star",
          },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
      {
        star: "blue-star",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
  },
];
