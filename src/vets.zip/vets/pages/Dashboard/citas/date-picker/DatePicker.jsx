import React, { useRef, useState } from "react";
import { DateRangePicker } from "react-bootstrap-daterangepicker";
import "bootstrap-daterangepicker/daterangepicker.css";
import moment from "moment";
import "./datePicker.scss";
function SingleInputDateRangePicker() {
  const keyRef = useRef();
  const [dates, setDates] = useState({
    startDate: moment("2020/03/01"),
    endDate: moment("2020/03/15"),
  });
  const [ranges, setRanges] = useState({
    "First Range": [moment().subtract(2, "days"), moment().add(2, "days")],
  });

  const handleApply = (event, picker) => {
    setDates({
      startDate: picker.startDate,
      endDate: picker.endDate,
    });

   
    picker.hide();
  };

  const handleShow = (event, picker) => {
  
    picker.autoApply = false;
  };

  return (
    <>
      <div className="picker">
        <DateRangePicker
          ref={keyRef}
          initialSettings={{
            ranges,
            autoApply: true,
          }}
          onApply={handleApply}
          onShow={handleShow}>
          <input  type="text" className="form-control dateinput col-4" />
        </DateRangePicker>
        <span className="fa-regular fa-calendar icon"></span>
      </div>
    </>
  );
}

export default SingleInputDateRangePicker;