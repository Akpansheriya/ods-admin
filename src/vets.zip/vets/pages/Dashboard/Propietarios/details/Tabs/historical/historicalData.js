export const historicalData = [
  {
    COD: "#12323",
    MASCOTA: "HACHIKO ",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
    ],
    ESTADO: "Pendiente",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
      {
        star: "bi bi-star-fill grey",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill blank",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill blank",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill blank",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
  {
    COD: "#12323",
    MASCOTA: "HACHIKO",
    HORARIO: "9:15 - 9:45",
    FECHA: "10 Feb 2021",
    star: [
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
      {
        star: "bi bi-star-fill",
      },
    ],
    ESTADO: "Completado",

    ACCIONES: "Ver detalles",
    PATH:"/dashboard/citas"
  },
];
