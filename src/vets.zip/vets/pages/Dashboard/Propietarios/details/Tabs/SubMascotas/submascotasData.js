export const submascotasData = [
  {
    COD: "#12323",
    NOMBRE: "HACHIKO",
    ESPECIE: "CANINO",
    SEXO: "MASCULINO",
    EDAD: "5",
    DETALLES: "Ver detalles",
  },
  {
    COD: "#12323",
    NOMBRE: "SCIIBYDOO",
    ESPECIE: "CANINO",
    SEXO: "MASCULINO",
    EDAD: "5",
    DETALLES: "Ver detalles",
  },
];
