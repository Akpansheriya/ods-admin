import React, { useState } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";
import timeGridPlugin from "@fullcalendar/timegrid";
import "./calendario.scss";
import { Button } from "react-bootstrap";
import Event from "./add event/Event";
import esLocale from "@fullcalendar/core/locales/es";
function Calendario() {
  const [lists, setLists] = useState([]);
  const [eventData, setEventData] = useState({
    title: "",
    description: "",
    location: "",
    startDate: "",
    startTime: "",
    endDate: "",
    endTime: "",
  });

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  return (
    <div className="calendario">
      <div className="main-title-box">
        <div>
          <p className="calendario-detail-main-title">Calendario de Citas</p>
          <p className="calendario-detail-sub-title">Pacientes</p>
        </div>
        <Button onClick={handleShow}>Añadir evento</Button>
      </div>
      <div className="maincontainer">
        <FullCalendar
          plugins={[
            dayGridPlugin,
            timeGridPlugin,
            interactionPlugin,
            listPlugin,
          ]}
          initialView="timeGridWeek"
          headerToolbar={{
            left: "prev,next today",
            center: "title",
            right: "dayGridMonth,timeGridWeek,timeGridDay,listWeek",
          }}
          events={lists}
          locales={[esLocale]}
          locale="es"
          dayHeaderFormat={{ weekday: 'short', day: 'numeric' }}
          slotLabelFormat={{
            hour: 'numeric',
            minute: '2-digit',
            hour12: true, 
          }}
          slotLabelContent={(arg) => {
            const hour = new Date(arg.date).getHours();
            const minute = new Date(arg.date).getMinutes();
            return `${hour === 0 ? '12' : hour > 12 ? hour - 12 : hour}:${minute === 0 ? '00' : minute} ${hour < 12 ? 'AM' : 'PM'}`;
          }}
          views={{
            dayGridMonth: { buttonText: "Mes" },
            timeGridWeek: { buttonText: "Semana" },
            timeGridDay: { buttonText: "Día" },
            listWeek: { buttonText: "Lista" },
          }}
        />

        <div></div>
      </div>

      <Event
        lists={lists}
        setLists={setLists}
        eventData={eventData}
        setEventData={setEventData}
        show={show}
        handleClose={handleClose}
      />
    </div>
  );
}

export default Calendario;
