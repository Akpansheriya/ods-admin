import React from 'react'
import {Row,Col} from 'react-bootstrap'
function Metricas() {
  return (
    <div>
         <p className="card-main-title">Métricas mes actual</p>
        <Row>
          <Col sm={12} md={3} lg={3}>
            <div className="card bg-body hoverable card-xl-stretch mb-xl-8">
              <div className="card-body">
                <i className="fa-regular fa-clock fa-icons"></i>

                <div className="main-heading mb-2 mt-4">Citas pendientes</div>

                <div className="sub-heading">9 </div>
              </div>
            </div>
          </Col>
          <Col sm={12} md={3} lg={3}>
            <div className="card bg-body hoverable card-xl-stretch mb-xl-8">
              <div className="card-body">
                <i className="fa-regular fa-calendar fa-icons"></i>

                <div className="main-heading mb-2 mt-4">Citas totales</div>

                <div className="sub-heading">124</div>
              </div>
            </div>
          </Col>
          <Col sm={12} md={3} lg={3}>
            <div className="card bg-body hoverable card-xl-stretch mb-xl-8">
              <div className="card-body">
                <i className="fa-regular fa-face-frown fa-icons"></i>

                <div className="main-heading mb-2 mt-4">Citas no asistidas</div>

                <div className="sub-heading">4</div>
              </div>
            </div>
          </Col>
          <Col sm={12} md={3} lg={3}>
            <div className="card bg-body hoverable card-xl-stretch mb-xl-8">
              <div className="card-body">
                <i class="fa-solid fa-user-plus fa-icons"></i>

                <div className="main-heading mb-2 mt-4">Pacientes nuevos</div>

                <div className="sub-heading">12</div>
              </div>
            </div>
          </Col>
        </Row>
    </div>
  )
}

export default Metricas