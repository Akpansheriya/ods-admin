import React from 'react'
import {Button} from "react-bootstrap"

function ProximasCitas() {
   
  return (
    <div className='calendar-card-wrapper2'>
         <div className="card card-flush h-lg-100 ">
              <div className="header-section align-items-start">
                <p className="calendar-p">Próximas citas agendadas</p>
                <div className="calendar-box">
                  <Button
                    href="#"
                   
                    className="calendar-btn"
                  >
                    <i className="fa-regular fa-calendar"></i>
                    Ver Calendario
                  </Button>
                </div>
              </div>
              <div className="card-body">
                <ul
                  className="nav nav-pills d-flex flex-nowrap hover-scroll-x py-2"
                  role="tablist"
                >
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_2"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">MAR</span>
                      <span className="fs-6 fw-bold">23</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary "
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_1"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">MAR</span>
                      <span className="fs-6 fw-bold">23</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_2"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">MIE</span>
                      <span className="fs-6 fw-bold">24</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_3"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">JUE</span>
                      <span className="fs-6 fw-bold">25</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_4"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">VIE</span>
                      <span className="fs-6 fw-bold">26</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">SAB</span>
                      <span className="fs-6 fw-bold">27</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_6"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">DOM</span>
                      <span className="fs-6 fw-bold">28</span>
                    </a>
                  </li>

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_7"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">LUN</span>
                      <span className="fs-6 fw-bold">29</span>
                    </a>
                  </li>
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_9"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold"> MAR</span>
                      <span className="fs-6 fw-bold">31</span>
                    </a>
                  </li>
                  
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_3"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">MIE</span>
                      <span className="fs-6 fw-bold">01</span>
                    </a>
                  </li>

                

                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">JUE</span>
                      <span className="fs-6 fw-bold">02</span>
                    </a>
                  </li>
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">VIE</span>
                      <span className="fs-6 fw-bold">03</span>
                    </a>
                  </li>
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">SAB</span>
                      <span className="fs-6 fw-bold">04</span>
                    </a>
                  </li>
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">DOM</span>
                      <span className="fs-6 fw-bold">05</span>
                    </a>
                  </li>
                  <li className="nav-item me-1" role="presentation">
                    <a
                      className="nav-link btn d-flex flex-column flex-center rounded-pill min-w-45px me-2 py-4 px-3 btn-active-primary"
                      data-bs-toggle="tab"
                      href="#kt_schedule_day_5"
                      aria-selected="false"
                      tabIndex="-1"
                      role="tab"
                    >
                      <span className="opacity-50 fs-7 fw-semibold">LUN</span>
                      <span className="fs-6 fw-bold">06</span>
                    </a>
                  </li>
                </ul>
                <div
                  id="kt_schedule_day_1"
                  className="tab-panel fade show active"
                  role="tabpanel"
                >
                  <div className="d-flex flex-stack position-relative mt-8">
                    <div className="position-absolute h-100 w-4px bg-secondary rounded top-0 start-0"></div>
                    <div className="fw-semibold ms-5 text-gray-600 text-start">
                      <div className="fs-5">
                        12:00 - 13:00
                        <span className="fs-7 text-gray-400 text-uppercase"> pm</span>
                      </div>
                      <a
                        href="#"
                        className="fs-5 fw-bold text-gray-800 text-hover-primary mb-2"
                      >
                        Cita #12323 - CUBAS TORRES, CARLOS ENRIQUE ...
                      </a>
                    </div>
                    <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                  </div>

                  <div className="d-flex flex-stack position-relative mt-8">
                    <div className="position-absolute h-100 w-4px bg-secondary rounded top-0 start-0"></div>
                    <div className="fw-semibold ms-5 text-gray-600 text-start">
                      <div className="fs-5">
                        9:00 - 10:00
                        <span className="fs-7 text-gray-400 text-uppercase"> am</span>
                      </div>
                      <a
                        href="#"
                        className="fs-5 fw-bold text-gray-800 text-hover-primary mb-2"
                      >
                        Cita #12323 - CUBAS TORRES, CARLOS ENRIQUE ...
                      </a>
                    </div>
                    <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                  </div>

                  <div className="d-flex flex-stack position-relative mt-8">
                    <div className="position-absolute h-100 w-4px bg-secondary rounded top-0 start-0"></div>
                    <div className="fw-semibold ms-5 text-gray-600 text-start">
                      <div className="fs-5">
                        16:30 - 17:30
                        <span className="fs-7 text-gray-400 text-uppercase"> pm</span>
                      </div>
                      <a
                        href="#"
                        className="fs-5 fw-bold text-gray-800 text-hover-primary mb-2"
                      >
                        Cita #12323 - CUBAS TORRES, CARLOS ENRIQUE ...
                      </a>
                    </div>
                    <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                  </div>
                 
                </div>
              </div>
            </div>
    </div>
  )
}

export default ProximasCitas