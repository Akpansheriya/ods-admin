import React from 'react'
import {Button} from "react-bootstrap"
function Medicamentos() {
  return (
    <div>
         <div className="calendar-card-wrapper-medicamentos">
                <div className="main-table-title">
                  <p>Medicamentos Actualizados</p>
                </div>

                <table>
                  <thead>
                    <tr>
                      <th>SKU</th>
                      <th>PRODUCTOS</th>
                      <th>PRESENTACIÓN</th>
                      <th>DETALLES</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>02694001</td>
                      <td>PARACETAMOL 500MG TABLETA</td>
                      <td>CAJA 100 UN</td>
                      <td>
                        <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                      </td>
                    </tr>
                    <tr>
                      <td>02694001</td>
                      <td>PARACETAMOL 500MG TABLETA</td>
                      <td>CAJA 100 UN</td>
                      <td>
                        <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                      </td>
                    </tr>
                    <tr>
                      <td>02694001</td>
                      <td>PARACETAMOL 500MG TABLETA</td>
                      <td>CAJA 100 UN</td>
                      <td>
                        <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                      </td>
                    </tr>
                    <tr>
                      <td>02694001</td>
                      <td>PARACETAMOL 500MG TABLETA</td>
                      <td>CAJA 100 UN</td>
                      <td>
                      <a
                      href="#"
                      className="btn btn-bg-light btn-active-color-primary btn-sm"
                    >
                      Ver detalles
                    </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
    </div>
  )
}

export default Medicamentos